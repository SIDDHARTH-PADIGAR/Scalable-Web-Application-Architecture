How to run this test?

Build, then run...

`go test -v timeout 10m`

