Uses a module from the terraform registry:

https://github.com/hashicorp/terraform-aws-consul